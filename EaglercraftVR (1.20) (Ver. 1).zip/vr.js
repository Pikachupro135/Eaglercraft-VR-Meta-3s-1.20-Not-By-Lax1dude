// ... at top of file (make sure vr.js is an ES module import-capable file)
import { createMinecraftHand } from './vr-hands.js';

// Example function to get the player's skin URL.
// Replace this logic with the actual place your client stores the skin URL.
// The loader is flexible: pass null to use the default color hand.
function getPlayerSkinURL() {
  // Common options to try:
  // 1) window.playerSkinUrl (if your client exposes it)
  // 2) window.game?.player?.skinUrl (example)
  // 3) read from your game's DOM or localStorage, etc.
  // Replace the lines below with the exact accessor used by your client.

  if (window.playerSkinUrl) return window.playerSkinUrl;
  if (window.game && window.game.player && window.game.player.skinUrl) return window.game.player.skinUrl;
  // fallback: try to read skin URL from a known element (example)
  // const el = document.getElementById('player-skin-url'); if (el) return el.textContent;
  return null; // no skin found
}

async function attachMinecraftHandsToGrips(gripLeft, gripRight) {
  const skinUrl = getPlayerSkinURL();
  try {
    const leftHand = await createMinecraftHand(skinUrl, true, 1.0);
    const rightHand = await createMinecraftHand(skinUrl, false, 1.0);
    // Remove any previous placeholder children if needed
    gripLeft.add(leftHand);
    gripRight.add(rightHand);
  } catch (e) {
    console.error("Failed to create Minecraft hands:", e);
  }
}

// After you create gripLeft and gripRight:
attachMinecraftHandsToGrips(gripLeft, gripRight);
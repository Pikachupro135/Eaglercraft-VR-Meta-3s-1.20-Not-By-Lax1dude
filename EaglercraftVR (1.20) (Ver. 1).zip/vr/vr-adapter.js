// vr-adapter.js - adapter that maps vr-action events to configured functions and provides XR hooks.
const VRAdapter = (function() {
  let cfg = {
    attackDown: () => {},
    attackUp: () => {},
    useDown: () => {},
    useUp: () => {},
    setMove: (x,y) => {},
    openInventory: () => {},
    toggleMenu: () => {},
    hideFirstPersonArms: () => {
      const el1 = document.getElementById('first-person');
      const el2 = document.querySelector('.first-person-arms');
      if (el1) el1.style.display = 'none';
      if (el2) el2.style.display = 'none';
    },
    showFirstPersonArms: () => {
      const el1 = document.getElementById('first-person');
      const el2 = document.querySelector('.first-person-arms');
      if (el1) el1.style.display = '';
      if (el2) el2.style.display = '';
    }
  };

  function configure(map) { cfg = Object.assign(cfg, map); }

  function onVRAction(e) {
    const d = e.detail;
    if (!d) return;
    if (d.type === 'trigger') {
      if (d.action === 'start') cfg.attackDown();
      if (d.action === 'end') cfg.attackUp();
    } else if (d.type === 'squeeze') {
      if (d.action === 'start') cfg.useDown();
      if (d.action === 'end') cfg.useUp();
    } else if (d.type === 'thumbstick' && d.action === 'move') {
      cfg.setMove(d.x || 0, -(d.y || 0));
    } else if (d.type === 'button' && d.action === 'pressed') {
      if (d.index === 3) cfg.openInventory();
      if (d.index === 4) cfg.toggleMenu();
    }
  }

  window.addEventListener('vr-action', onVRAction);

  function onXRSessionStart() { if (cfg.hideFirstPersonArms) cfg.hideFirstPersonArms(); }
  function onXRSessionEnd()   { if (cfg.showFirstPersonArms) cfg.showFirstPersonArms(); }

  return { configure, onXRSessionStart, onXRSessionEnd };
})();

window.VRAdapter = VRAdapter;
export default VRAdapter;
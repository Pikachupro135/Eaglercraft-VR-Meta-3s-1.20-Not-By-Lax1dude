// vr/vr.js - WebXR runtime using procedural blocky hands (no GLB required).
import * as THREE from "https://unpkg.com/three@0.150.0/build/three.module.js";
import { VRButton } from "https://unpkg.com/three@0.150.0/examples/jsm/webxr/VRButton.js";
import { XRControllerModelFactory } from "https://unpkg.com/three@0.150.0/examples/jsm/webxr/XRControllerModelFactory.js";
import VRAdapter from './vr-adapter.js';
import { PostProcess } from './vr-postprocess.js';

const app = document.getElementById('app');
const debug = document.getElementById('debug');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);

const camera = new THREE.PerspectiveCamera(70, window.innerWidth/window.innerHeight, 0.01, 1000);
camera.position.set(0, 1.6, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;
renderer.outputEncoding = THREE.sRGBEncoding;
app.appendChild(renderer.domElement);
document.body.appendChild(VRButton.createButton(renderer));

// Lighting + floor
const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1.0); hemi.position.set(0, 20, 0); scene.add(hemi);
const dir = new THREE.DirectionalLight(0xffffff, 0.4); dir.position.set(3, 10, 10); scene.add(dir);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(100,100), new THREE.MeshStandardMaterial({ color: 0x667744 })); floor.rotation.x = -Math.PI/2; floor.position.y = 0; scene.add(floor);

// Anchor block
const anchor = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.6,0.6), new THREE.MeshStandardMaterial({color: 0x8b4513}));
anchor.position.set(0, 0.3, -2);
scene.add(anchor);

// Controllers + grips
const controllerLeft = renderer.xr.getController(0);
const controllerRight = renderer.xr.getController(1);
scene.add(controllerLeft);
scene.add(controllerRight);

const gripLeft = renderer.xr.getControllerGrip(0);
const gripRight = renderer.xr.getControllerGrip(1);
const controllerModelFactory = new XRControllerModelFactory();
gripLeft.add(controllerModelFactory.createControllerModel(gripLeft));
gripRight.add(controllerModelFactory.createControllerModel(gripRight));
scene.add(gripLeft);
scene.add(gripRight);

// Procedural blocky hand builder (uses player's skin if available by URL)
function createBlockyHandMesh(skinImg, isLeft = true) {
  const group = new THREE.Group();

  const skinTex = skinImg ? new THREE.Texture(skinImg) : null;
  if (skinTex) { skinTex.needsUpdate = true; skinTex.magFilter = THREE.NearestFilter; skinTex.minFilter = THREE.LinearMipmapLinearFilter; skinTex.encoding = THREE.sRGBEncoding; }

  const sleeveColor = 0x3b83bd;
  const skinColor = 0xffdbac;
  const sleeveMat = skinTex ? new THREE.MeshStandardMaterial({ map: skinTex }) : new THREE.MeshStandardMaterial({ color: sleeveColor });
  const skinMat   = skinTex ? new THREE.MeshStandardMaterial({ map: skinTex }) : new THREE.MeshStandardMaterial({ color: skinColor });

  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12,0.28,0.12), sleeveMat);
  arm.position.set(0, -0.14, 0);
  group.add(arm);

  const hand = new THREE.Mesh(new THREE.BoxGeometry(0.12,0.12,0.12), skinMat);
  hand.position.set(0, -0.38, 0.03);
  group.add(hand);

  const finger = new THREE.Mesh(new THREE.BoxGeometry(0.06,0.06,0.06), skinMat);
  finger.position.set(0, -0.44, 0.07);
  group.add(finger);

  group.rotation.x = -0.2;
  group.position.set(isLeft ? -0.03 : 0.03, 0.15, -0.05);
  group.scale.set(1.05, 1.05, 1.05);

  return group;
}

// Attempt to load player's skin image from common accessor
async function loadPlayerSkinImage() {
  const url = (window.playerSkinUrl) || (window.game && window.game.player && window.game.player.skinUrl) || (localStorage && localStorage.getItem('playerSkinUrl')) || null;
  if (!url) return null;
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

async function attachProceduralHands() {
  const img = await loadPlayerSkinImage();
  const left = createBlockyHandMesh(img, true);
  const right = createBlockyHandMesh(img, false);
  while (gripLeft.children.length) gripLeft.remove(gripLeft.children[0]);
  while (gripRight.children.length) gripRight.remove(gripRight.children[0]);
  gripLeft.add(left);
  gripRight.add(right);
}
attachProceduralHands();

// Postprocessing (pixelation), can be applied in XR
const usePostProcessing = true;
const usePostProcessingInXR = true;
let postProcess = null;
if (usePostProcessing) {
  try { postProcess = new PostProcess(renderer, scene, camera, { pixelSize: 4, paletteLevels: 32.0, xrEnabled: usePostProcessingInXR }); debug.textContent = 'PostProcess enabled'; }
  catch (e) { console.warn('PostProcess init failed', e); postProcess = null; }
}

// Generic event emitter for VRAdapter
function emitVRAction(detail) {
  window.dispatchEvent(new CustomEvent('vr-action', { detail }));
  debug.textContent = JSON.stringify(detail);
}

function setupController(controller, defaultHand) {
  controller.addEventListener('connected', (ev) => { controller.gamepad = ev.data.gamepad; controller.handedness = ev.data.handedness || defaultHand; });
  controller.addEventListener('disconnected', () => { controller.gamepad = null; });
  controller.addEventListener('selectstart', () => emitVRAction({ hand: controller.handedness, type: 'trigger', action: 'start' }));
  controller.addEventListener('selectend',   () => emitVRAction({ hand: controller.handedness, type: 'trigger', action: 'end' }));
  controller.addEventListener('squeezestart', () => emitVRAction({ hand: controller.handedness, type: 'squeeze', action: 'start' }));
  controller.addEventListener('squeezeend',   () => emitVRAction({ hand: controller.handedness, type: 'squeeze', action: 'end' }));
}
setupController(controllerLeft, 'left'); setupController(controllerRight, 'right');

function pollGamepads() {
  [controllerLeft, controllerRight].forEach(c => {
    const gp = c.gamepad;
    if (!gp) return;
    gp.buttons.forEach((b,i) => { if (b.pressed) emitVRAction({ hand: c.handedness, type: 'button', index: i, action: 'pressed', value: b.value }); });
    if (gp.axes && gp.axes.length >= 2) {
      const x = gp.axes[0], y = gp.axes[1];
      if (Math.abs(x) > 0.02 || Math.abs(y) > 0.02) emitVRAction({ hand: c.handedness, type: 'thumbstick', action: 'move', x, y });
    }
  });
}

// XR session hooks
renderer.xr.addEventListener('sessionstart', () => {
  if (window.VRAdapter && window.VRAdapter.onXRSessionStart) window.VRAdapter.onXRSessionStart();
  try { if (document.fullscreenEnabled) document.documentElement.requestFullscreen().catch(()=>{}); } catch(e){}
});
renderer.xr.addEventListener('sessionend', () => {
  if (window.VRAdapter && window.VRAdapter.onXRSessionEnd) window.VRAdapter.onXRSessionEnd();
  try { if (document.fullscreenElement) document.exitFullscreen().catch(()=>{}); } catch(e){}
});

// Render loop
renderer.setAnimationLoop((t, frame) => {
  pollGamepads();
  if (postProcess && renderer.xr.isPresenting && postProcess.xrEnabled) {
    postProcess.renderXR(renderer, scene, camera);
  } else if (postProcess && !renderer.xr.isPresenting) {
    postProcess.render();
  } else {
    renderer.render(scene, camera);
  }
});

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  if (postProcess) postProcess.setSize(window.innerWidth, window.innerHeight);
});
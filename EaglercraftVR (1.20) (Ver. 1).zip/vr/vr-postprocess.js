import * as THREE from "https://unpkg.com/three@0.150.0/build/three.module.js";
import { PixelateShader } from "./shaders/pixelateShader.js";

export class PostProcess {
  constructor(renderer, scene, camera, options = {}) {
    this.renderer = renderer;
    this.scene = scene;
    this.camera = camera;
    this.pixelSize = options.pixelSize || 4;
    this.paletteLevels = options.paletteLevels || 32.0;
    this.xrEnabled = !!options.xrEnabled;

    const w = Math.max(64, Math.floor(renderer.domElement.width / 2));
    const h = Math.max(64, Math.floor(renderer.domElement.height / 2));
    this.renderTarget = new THREE.WebGLRenderTarget(w, h, { minFilter: THREE.LinearFilter, magFilter: THREE.NearestFilter, format: THREE.RGBAFormat });

    this.orthoScene = new THREE.Scene();
    this.orthoCamera = new THREE.OrthographicCamera(-1,1,1,-1,0,1);
    const geom = new THREE.PlaneGeometry(2,2);

    this.mat = new THREE.ShaderMaterial({
      vertexShader: PixelateShader.vertexShader,
      fragmentShader: PixelateShader.fragmentShader,
      uniforms: {
        tDiffuse: { value: null },
        resolution: { value: [w, h] },
        pixelSize: { value: this.pixelSize },
        paletteLevels: { value: this.paletteLevels }
      },
      depthTest: false,
      depthWrite: false
    });
    const quad = new THREE.Mesh(geom, this.mat);
    this.orthoScene.add(quad);

    this.setSize(renderer.domElement.clientWidth, renderer.domElement.clientHeight);
  }

  setSize(w, h) {
    const rtW = Math.max(64, Math.floor(w / 2));
    const rtH = Math.max(64, Math.floor(h / 2));
    this.renderTarget.setSize(rtW, rtH);
    this.mat.uniforms.resolution.value = [rtW, rtH];
  }

  render() {
    this.renderer.setRenderTarget(this.renderTarget);
    this.renderer.render(this.scene, this.camera);
    this.renderer.setRenderTarget(null);
    this.mat.uniforms.tDiffuse.value = this.renderTarget.texture;
    this.mat.uniforms.pixelSize.value = this.pixelSize;
    this.mat.uniforms.paletteLevels.value = this.paletteLevels;
    this.renderer.render(this.orthoScene, this.orthoCamera);
  }

  renderXR(renderer, scene, camera) {
    renderer.setRenderTarget(this.renderTarget);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    renderer.clearDepth();
    this.mat.uniforms.tDiffuse.value = this.renderTarget.texture;
    this.mat.uniforms.pixelSize.value = this.pixelSize;
    this.mat.uniforms.paletteLevels.value = this.paletteLevels;
    renderer.render(this.orthoScene, this.orthoCamera);
  }
}
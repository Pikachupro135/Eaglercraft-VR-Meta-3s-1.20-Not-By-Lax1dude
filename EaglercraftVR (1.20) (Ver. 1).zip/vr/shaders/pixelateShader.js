export const PixelateShader = {
  uniforms: {
    "tDiffuse": { value: null },
    "resolution": { value: [800, 600] },
    "pixelSize": { value: 4.0 },
    "paletteLevels": { value: 32.0 }
  },

  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,

  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform vec2 resolution;
    uniform float pixelSize;
    uniform float paletteLevels;
    varying vec2 vUv;

    void main() {
      vec2 px = vUv * resolution;
      vec2 snapped = floor(px / pixelSize) * pixelSize + pixelSize * 0.5;
      vec2 uv = snapped / resolution;
      vec4 color = texture2D(tDiffuse, uv);
      color.rgb = floor(color.rgb * paletteLevels + 0.5) / paletteLevels;
      gl_FragColor = color;
    }
  `
};